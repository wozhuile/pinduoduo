//
//  home_super_brandTableViewCell.h
//  PinDuoDuoTest
//
//  Created by mac on 16/6/29.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface home_super_brandTableViewCell : UITableViewCell



//@property (weak, nonatomic) IBOutlet UILabel *lookMore;





//@property (weak, nonatomic) IBOutlet UILabel *timeLabel;

///@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
//@property (weak, nonatomic) IBOutlet UILabel *timeAlertLabel;



//@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *firstIcon;

//@property (weak, nonatomic) IBOutlet UILabel *firstPricelabel;


//@property (weak, nonatomic) IBOutlet UIImageView *middleIcon;
//@property (weak, nonatomic) IBOutlet UILabel *middlePriceLabel;


//@property (weak, nonatomic) IBOutlet UIImageView *lastIcon;

//@property (weak, nonatomic) IBOutlet UILabel *lastPriceLabel;

//@property (weak, nonatomic) IBOutlet UILabel *searchMoreLabel;



@end
