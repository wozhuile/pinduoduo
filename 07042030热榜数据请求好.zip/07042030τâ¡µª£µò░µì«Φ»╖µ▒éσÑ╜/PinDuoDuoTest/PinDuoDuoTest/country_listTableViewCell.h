//
//  country_listTableViewCell.h
//  PinDuoDuoTest
//
//  Created by mac on 16/7/2.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface country_listTableViewCell : UITableViewCell
#pragma mark scrollView
@property(nonatomic,strong)UIScrollView*scrollView;

@end
