//
//  PDDMeViewController.h
//  PinDuoDuoTest
//
//  Created by mac on 16/6/28.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PDDMeViewController : UIViewController

@property(nonatomic,strong)UITableView*personCentertableView;



@end
