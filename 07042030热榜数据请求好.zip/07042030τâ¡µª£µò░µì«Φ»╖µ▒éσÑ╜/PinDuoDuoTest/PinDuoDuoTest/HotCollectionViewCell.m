//
//  HotCollectionViewCell.m
//  PinDuoDuoTest
//
//  Created by mac on 16/6/30.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "HotCollectionViewCell.h"

@implementation HotCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

@end
