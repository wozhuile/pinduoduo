//
//  DataModels.h
//
//  Created by   on 16/7/2
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import "RankGroup.h"#import "RankCountryList.h"#import "RankPromotionList.h"#import "RankGoodsList.h"#import "RankBaseModle.h"