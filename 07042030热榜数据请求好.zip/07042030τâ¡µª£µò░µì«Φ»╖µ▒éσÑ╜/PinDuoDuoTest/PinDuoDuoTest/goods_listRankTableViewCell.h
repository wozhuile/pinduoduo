//
//  goods_listRankTableViewCell.h
//  PinDuoDuoTest
//
//  Created by mac on 16/7/2.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface goods_listRankTableViewCell : UITableViewCell

@end
