//
//  home_recommend_subjectsTableViewCell.h
//  PinDuoDuoTest
//
//  Created by mac on 16/6/29.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface home_recommend_subjectsTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *subject;
@property (weak, nonatomic) IBOutlet UILabel *modeLook;

@property (weak, nonatomic) IBOutlet UIImageView *comonArrow;


@end
